---
name: 🐛 Bug Report
about: Submit discovered bugs
---

<!--
Please ensure you have read [documentation], and provide all the information required by this template.
Otherwise the issue will be closed immediately.Please do not repeat the issue.
-->

### BUG occurrence address

### What is expected?

### What is actually happening?

### Additional info (logs errors etc)

<!--
Please ensure you have deployed the [master branch](https://github.com/nexmoe/hexo-theme-nexmoe/tree/master) 
-->