---
name: 🍰 功能需求
about: 提交新的功能需求
---

<!--
请确保 [文档](https://docs.nexmoe.com) 和 [issue](https://github.com/nexmoe/hexo-theme-nexmoe/issues) 中没有相关内容，并按照模版提供信息
否则 issue 将被立即关闭
-->

### 这是一个什么样的功能？

### 这个功能可以干什么？

### 额外描述